NOAA GFS data retrieved through Open-Meteo (CC BY 4.0). Source: https://open-meteo.com/en/docs/previous-runs-api
Raw responses and manifests preserve request parameters and hashes. See research/PROTOCOL_V2.md and DATA_QUALITY_AMENDMENT.md. API commercial-use terms are separate. These grid profiles are not panchayat observations.
Run validate_real.py --help for reproduction arguments. Requires Python, numpy and scikit-learn.
